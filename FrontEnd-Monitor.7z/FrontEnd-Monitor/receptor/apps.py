'''
Arquivo que vem com o django
'''
from django.apps import AppConfig

class ReceptorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'receptor'
