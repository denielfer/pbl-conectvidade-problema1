'''
Arquivo que vem com o django
'''
from django.contrib import admin

# Register your models here.
