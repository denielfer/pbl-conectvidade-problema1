'''
Arquivo que vem com o django
'''
from django.test import TestCase

# Create your tests here.
