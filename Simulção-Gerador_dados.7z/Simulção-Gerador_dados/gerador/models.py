'''
Arquivo que vem com o django
'''
from django.db import models

# Create your models here.
